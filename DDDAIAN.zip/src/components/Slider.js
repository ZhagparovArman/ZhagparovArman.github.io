import { useState, useEffect } from "react";

const Slider = ({ children }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [length, setLength] = useState(children.length);
  const [range, setRange] = useState(1);

  useEffect(() => {
    setLength(children.length);
  }, [children]);

  const nextSlide = () => {
    if (currentIndex < length - 1) {
      setCurrentIndex(prevState => prevState + 1);
      setRange(currentIndex + 2);
    }
  };

  const prevSlide = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prevState => prevState - 1);
      setRange(currentIndex);
    }
  };

  const handleChange = e => {
    setRange(e.target.value);
    setCurrentIndex(e.target.value - 1);
  };

  return (
    <div className="slider">
      <div className="slider__wrapper">
        <div className="slider__content-wrapper">
          <div
            className="slider__content"
            style={{ transform: `translateX(-${currentIndex * 100}%)` }}
          >
            {children}
          </div>
        </div>
        <div className="slider__nav">
          <div className="slider__btn-wrapper">
            <button
              onClick={prevSlide}
              className="slider__btn-prev btn"
            ></button>
            <button
              onClick={nextSlide}
              className="slider__btn-next btn"
            ></button>
          </div>
          <div className="slider__range-bar">
            <span className="slider__range-bar-count">0{range}</span>
            <input
              type="range"
              className="slider__range"
              name="range"
              min="0"
              max="3"
              step="1"
              value={range}
              onChange={handleChange}
            />
            <span className="slider__range-bar-count">03</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Slider;
