const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer__wrapper">
        <div className="footer__container">
          <div className="footer__contacts">
            <a
              href="#"
              className="footer__logo-link"
              style={{ background: "#000000" }}
            >
              <img
                className="footer__logo"
                src={require("../assets/images/logo.svg").default}
                alt="logo"
              />
            </a>
            <ul className="footer__contacts-link">
              <li className="footer__contacts-item">
                <a className="footer__contacts-item-link" href="">
                  87778787878744545
                </a>
              </li>
              <li className="footer__contacts-item">
                <a className="footer__contacts-item-link" href="">
                  b.tolebaev@gmail.com
                </a>
              </li>
              <li className="footer__contacts-item">
                <a className="footer__contacts-item-link" href="">
                  Almaty, Dostyk ave. 108, 8 floor
                </a>
              </li>
            </ul>
          </div>
          <div className="footer__sitemap">
            <h2 className="footer__header">Карта сайта</h2>
            <ul className="footer_nav">
              <li className="footer__nav-item">
                <a className="footer__nav-item-link" href="#">
                  Home
                </a>
              </li>
              <li className="footer__nav-item">
                <a className="footer__nav-item-link" href="#">
                  Pages
                </a>
              </li>
              <li className="footer__nav-item">
                <a className="footer__nav-item-link" href="#">
                  Products
                </a>
              </li>
              <li className="footer__nav-item">
                <a className="footer__nav-item-link" href="#">
                  Shop
                </a>
              </li>
              <li className="footer__nav-item">
                <a className="footer__nav-item-link" href="#">
                  Contacts
                </a>
              </li>
            </ul>
          </div>
          <div className="footer__contact-us-form">
            <h2 className="footer__header">У вас есть проект?</h2>
            <p className="footer__contact-us-form-content">
              Оставь тут свой e-mail, мы свяжемся <br /> с тобой как можно
              скорее.
            </p>
            <form className="footer__form">
              <input
                className="footer__input"
                type="text"
                placeholder="Your email"
              />
              <button className="footer__button">отправить</button>
            </form>
          </div>
        </div>
        <div className="footer__social">
          <ul className="footer__social-links">
            <li className="footer__social-item">
              <a className="footer__social-item-link" href="#">
                FB
              </a>
            </li>
            <li className="footer__social-item">
              <a className="footer__social-item-link" href="#">
                IG
              </a>
            </li>
            <li className="footer__social-item">
              <a className="footer__social-item-link" href="#">
                BE
              </a>
            </li>
          </ul>
          <p className="footer__copyright">©2020 Doover. All Rights Reserved</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
