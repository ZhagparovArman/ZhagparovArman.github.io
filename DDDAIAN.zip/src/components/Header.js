const Header = () => {
  return (
    <header className="page-header">
      <div className="page-header__wrapper">
        <a className="page-header__logo-link" href="#logo">
          <img
            className="page-header__logo"
            src={require("../assets/images/logo.svg").default}
            alt="logo"
          />
        </a>
        <nav className="page-header__nav">
          <button
            className="page-header__nav-btn"
            onClick={() => console.log("nav-btn-header")}
          ></button>
        </nav>
      </div>
    </header>
  );
};

export default Header;
