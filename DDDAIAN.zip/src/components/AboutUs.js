const AboutUs = () => {
  return (
    <section className="about-us">
      <div className="about-us__container">
        <div className="about-us__info">
          <div className="about-us__info-content">
            <h3 className="about-us__info-title">
              Гедонизм стабилизирует сенсибельный
            </h3>
            <p className="about-us__info-text">
              Дуализм конвенционален. Ирония возможна. Горизонт ожидания
              неоднозначен. Современная ситуация, по определению, индуктивно
              трансформирует межличностный даосизм. Одиночество творит глубокий
              катарсис. Агентская комиссия раскладывает на элементы{" "}
            </p>
          </div>
          <div className="about-us__info-img-wrapper">
            <img
              className="about-us__info-img"
              src="./img/about-us.jpg"
              alt="image"
            />
          </div>
        </div>
        <div className="about-us__stats">
          <div className="about-us__stats-info">
            <h3 className="about-us__stats-count">01</h3>
            <span className="about-us__stats-label">Катарсис</span>
          </div>
          <div className="about-us__stats-info">
            <h3 className="about-us__stats-count">02</h3>
            <span className="about-us__stats-label">VIP-мероприятие</span>
          </div>
          <div className="about-us__stats-info">
            <h3 className="about-us__stats-count">456</h3>
            <span className="about-us__stats-label">
              Позитивизм выстраивает{" "}
            </span>
          </div>
          <div className="about-us__stats-info">
            <h3 className="about-us__stats-count">2500</h3>
            <span className="about-us__stats-label">Согласно предыдущему</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
