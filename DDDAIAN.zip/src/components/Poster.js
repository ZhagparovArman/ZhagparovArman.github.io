import { useEffect, useState } from "react";
import Slider from "./Slider";

const Poster = () => {
  const [images, setImages] = useState([]);

  useEffect(() => {
    setImages(["./img/slide1.jpg", "./img/slide2.jpg", "./img/slide3.jpg"]);
  }, []);

  return (
    <section className="poster">
      <div className="poster__wrapper">
        <div className="poster__content content">
          <div className="content__wrapper">
            <p className="content__sub-text">2020 - Мебель</p>
            <h1 className="content__heading">Поведенческии таргетинг</h1>
          </div>
        </div>
        <Slider>
          {images.map(img => (
            <img className="poster__slider-imgs" src={img} alt="" />
          ))}
        </Slider>
      </div>
    </section>
  );
};

export default Poster;
