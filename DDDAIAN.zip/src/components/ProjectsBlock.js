const ProjectsBlock = () => {
  return (
    <section className="projects-block">
      <div className="projects-block__container">
        <div className="projects-block__item-group item-group-first">
          <div className="projects-block__item">
            <img
              className="projects-block__item-img item-img item-img--small"
              src="./img/project1.jpg"
              alt=""
            />
            <div className="projects-block__item-links">
              <a>
                <span className="projects-block__link-label">Проекты</span>
              </a>
              <div className="projects-block__item-title-wrapper">
                <a>
                  <h3 className="projects-block__item-title">Здравый смысл</h3>
                </a>
                <a>
                  <button className="projects-block__item-btn"></button>
                </a>
              </div>
            </div>
          </div>
          <div className="projects-block__item">
            <img
              className="projects-block__item-img item-img item-img--big"
              src="./img/project2.jpg"
              alt=""
            />
            <div className="projects-block__item-links">
              <a>
                <span className="projects-block__link-label">Проекты</span>
              </a>
              <div className="projects-block__item-title-wrapper">
                <a>
                  <h3 className="projects-block__item-title">
                    Прекрасноый маньеризм
                  </h3>
                </a>
                <a>
                  <button className="projects-block__item-btn"></button>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="projects-block__item-group item-group-second">
          <div className="projects-block__item">
            <img
              className="projects-block__item-img item-img item-img--small"
              src="./img/project4.jpg"
              alt=""
            />
            <div className="projects-block__item-links">
              <a>
                <span className="projects-block__link-label">Проекты</span>
              </a>
              <div className="projects-block__item-title-wrapper">
                <a>
                  <h3 className="projects-block__item-title">
                    Реализм изящный
                  </h3>
                </a>
                <a>
                  <button className="projects-block__item-btn"></button>
                </a>
              </div>
            </div>
          </div>
          <div className="projects-block__item">
            <img
              className="projects-block__item-img item-img item-img--big"
              src="./img/project3.jpg"
              alt=""
            />
            <div className="projects-block__item-links">
              <a>
                <span className="projects-block__link-label">Проекты</span>
              </a>
              <div className="projects-block__item-title-wrapper">
                <a>
                  <h3 className="projects-block__item-title">Энергия либидо</h3>
                </a>
                <a>
                  <button className="projects-block__item-btn"></button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProjectsBlock;
