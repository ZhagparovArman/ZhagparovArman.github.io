const Collaboration = () => {
  return (
    <section className="collaboration">
      <h3 className="collaboration__title">
        Давайте дружить! Стать партнером тут
      </h3>
      <div className="collaboration__action">
        <p className="collaboration__action-info">
          Флобер, описывая нервный припадок Эммы Бовари, переживает его сам.
        </p>
        <button className="collaboration__action-btn">оставить заявку</button>
      </div>
    </section>
  );
};

export default Collaboration;
