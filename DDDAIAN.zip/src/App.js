import { BrowserRouter as Router, Switch, Link, Route } from "react-router-dom";
import loadable from "@loadable/component";
import Header from "./components/Header";
import Footer from "./components/Footer";

const Main = loadable(() => import("./pages/Main"));
const About = loadable(() => import("./pages/About"));
const Projects = loadable(() => import("./pages/Projects"));
const Project = loadable(() => import("./pages/Project"));
const Vacancies = loadable(() => import("./pages/Vacancies"));

function App() {
  return (
    <Router>
      <>
        <Header />
        <Switch>
          <Route exact path="/" component={Main} />
          <Route path="/projects" component={Projects} />
          <Route path="/about" component={About} />
          <Route path="/project" component={Project} />
          <Route path="/vacancies" component={Vacancies} />
        </Switch>
        <Footer />
      </>
    </Router>
  );
}

export default App;
