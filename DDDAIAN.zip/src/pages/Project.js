const Project = () => {
  return (
    <section className="project">
      <div className="project__wrapper">
        <div className="project__heading">
          <div className="project__heading-content">
            <span className="project__heading-label">2020 - Проекты</span>
            <h2 className="project__heading-title">
              Холерик выстраивает этикет
            </h2>
          </div>
          <div className="project__heading-image-wrapper">
            <img
              className="project__heading-image"
              src="./img/heading.jpg"
              alt="image"
            />
          </div>
        </div>
        <div className="project__description">
          <p className="project__description-content">
            Весьма существенно следующее: онтогенез многопланово начинает
            структурализм, так Г.Корф формулирует собственную антитезу.
            Художественная богема заканчивает первоначальный горизонт ожидания.
          </p>
          <div className="project__description-img-wrapper">
            <img
              className="project__description-img"
              src="./img/description.jpg"
              alt="image"
            />
          </div>
        </div>
        <div className="project__photos">
          <div className="project__photos-info">
            <h3 className="project__photos-title">
              Меланхолик, определенно, традиционен.
            </h3>
            <p className="project__photos-content">
              Возвышенное образует фактографический монтаж, именно об этом
              комплексе движущих сил писал З.Фрейд в теории сублимации. Метод
              кластерного анализа, на первый взгляд, просветляет неизменный
              героический миф. Как было показано выше, художественное
            </p>
          </div>
          <div className="project__photos-img-wrapper photos-img-first">
            <img
              className="project__photos-img "
              src="./img/photo1.jpg"
              alt=""
            />
          </div>

          <div className="project__photos-img-wrapper photos-img-second">
            <img
              className="project__photos-img "
              src="./img/photo2.jpg"
              alt=""
            />
          </div>
          <div className="project__photos-img-wrapper photos-img-third">
            <img
              className="project__photos-img "
              src="./img/photo3.jpg"
              alt=""
            />
          </div>
        </div>
        <div className="project__info">
          <h3 className="project__info-title">
            Конструктивный текст актуальная задача
          </h3>
          <p className="project__info-content">
            Возвышенное образует фактографический монтаж, именно об этом
            комплексе движущих сил писал З.Фрейд в теории сублимации. Метод
            кластерного анализа, на первый взгляд, просветляет неизменный
            героический миф. Как было показано выше, художественное
            опосредование вызывает биографический метод, таким образом, сходные
            законы контрастирующего развития характерны и для процессов в
            психике.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Project;
