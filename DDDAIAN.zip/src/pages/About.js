const About = () => {
  return <>about</>;
};

export default About;
