const Projects = () => {
  return <section className="page-projects">projects</section>;
};

export default Projects;
