const Vacancies = () => {
  return (
    <section className="vacancies">
      <div className="vacancies__wrapper">
        <h2 className="vacancies__title">НАЙДИ РАБОТУ</h2>
        <ul className="vacancies__list">
          <li className="vacancies__item">
            <div className="vacancies__item-info">
              <span className="vacancies__item-info__category">Продажи</span>
              <h3 className="vacancies__item-info__name">Менеджер</h3>
              <a className="vacancies__item-info__btn" href="#">
                <span className="vacancies__item-info__btn__content btn-content">
                  Я хочу эту должность
                </span>
              </a>
            </div>
            <div className="vacancies__item-requirement">
              <span className="vacancies__item-requirement__title">
                Требования
              </span>
              <p className="vacancies__item-requirement__description">
                Творческая доминанта изящно использует символизм, подобный
                исследовательский подход к проблемам художественной типологии
                можно обнаружить у К.Фосслера. Эзотерическое трансформирует
              </p>
              <a className="vacancies__item-requirement__btn" href="#">
                <span className="vacancies__item-requirement__btn__content btn-content">
                  Я хочу эту должность
                </span>
              </a>
            </div>
          </li>
          <li className="vacancies__item">
            <div className="vacancies__item-info">
              <span className="vacancies__item-info__category">Дизайн</span>
              <h3 className="vacancies__item-info__name">
                Дизайнер интерьеров
              </h3>
              <a className="vacancies__item-info__btn" href="#">
                <span className="vacancies__item-info__btn__content btn-content">
                  Я хочу эту должность
                </span>
              </a>
            </div>
            <div className="vacancies__item-requirement">
              <span className="vacancies__item-requirement__title">
                Требования
              </span>
              <p className="vacancies__item-requirement__description">
                Творческая доминанта изящно использует символизм, подобный
                исследовательский подход к проблемам художественной типологии
                можно обнаружить у К.Фосслера. Эзотерическое трансформирует
              </p>
              <a className="vacancies__item-requirement__btn" href="#">
                <span className="vacancies__item-requirement__btn__content btn-content">
                  Я хочу эту должность
                </span>
              </a>
            </div>
          </li>
          <li className="vacancies__item">
            <div className="vacancies__item-info">
              <span className="vacancies__item-info__category">Продажи</span>
              <h3 className="vacancies__item-info__name">
                Директор отдела продаж
              </h3>
              <a className="vacancies__item-info__btn" href="#">
                <span className="vacancies__item-info__btn__content btn-content">
                  Я хочу эту должность
                </span>
              </a>
            </div>
            <div className="vacancies__item-requirement">
              <span className="vacancies__item-requirement__title">
                Требования
              </span>
              <p className="vacancies__item-requirement__description">
                Творческая доминанта изящно использует символизм, подобный
                исследовательский подход к проблемам художественной типологии
                можно обнаружить у К.Фосслера. Эзотерическое трансформирует
              </p>
              <a className="vacancies__item-requirement__btn" href="#">
                <span className="vacancies__item-requirement__btn__content btn-content">
                  Я хочу эту должность
                </span>
              </a>
            </div>
          </li>
          <li className="vacancies__item">
            <div className="vacancies__item-info">
              <span className="vacancies__item-info__category">Дизайнер</span>
              <h3 className="vacancies__item-info__name">3D-дизайнер</h3>
              <a className="vacancies__item-info__btn" href="#">
                <span className="vacancies__item-info__btn__content btn-content">
                  Я хочу эту должность
                </span>
              </a>
            </div>
            <div className="vacancies__item-requirement">
              <span className="vacancies__item-requirement__title">
                Требования
              </span>
              <p className="vacancies__item-requirement__description">
                Творческая доминанта изящно использует символизм, подобный
                исследовательский подход к проблемам художественной типологии
                можно обнаружить у К.Фосслера. Эзотерическое трансформирует
              </p>
              <a className="vacancies__item-requirement__btn" href="#">
                <span className="vacancies__item-requirement__btn__content btn-content">
                  Я хочу эту должность
                </span>
              </a>
            </div>
          </li>
          <li className="vacancies__item">
            <div className="vacancies__item-info">
              <span className="vacancies__item-info__category">Продажи</span>
              <h3 className="vacancies__item-info__name">
                Директор отдела продаж
              </h3>
              <a className="vacancies__item-info__btn" href="#">
                <span className="vacancies__item-info__btn__content btn-content">
                  Я хочу эту должность
                </span>
              </a>
            </div>
            <div className="vacancies__item-requirement">
              <span className="vacancies__item-requirement__title">
                Требования
              </span>
              <p className="vacancies__item-requirement__description">
                Творческая доминанта изящно использует символизм, подобный
                исследовательский подход к проблемам художественной типологии
                можно обнаружить у К.Фосслера. Эзотерическое трансформирует
              </p>
              <a className="vacancies__item-requirement__btn" href="#">
                <span className="vacancies__item-requirement__btn__content btn-content">
                  Я хочу эту должность
                </span>
              </a>
            </div>
          </li>
        </ul>
      </div>
    </section>
  );
};

export default Vacancies;
