import { useState } from "react";
import Header from "../components/Header";
import Poster from "../components/Poster";
import Footer from "../components/Footer";
import AboutUs from "../components/AboutUs";
import Collaboration from "../components/Collaboration";
import ProjectsBlock from "../components/ProjectsBlock";
const Main = () => {
  const [range, setRange] = useState(1);

  const handleChange = e => {
    setRange(e.target.value);
    // setCurrentIndex(e.target.value - 1);
  };
  return (
    <section className="main">
      <Poster />
      <div className="main__wrapper">
        <div className="main__news">
          <h2 className="main__news-heading">Что нового?</h2>
          <div className="main__news-container">
            <div className="main__news-group">
              <div className="main__news-card">
                <div className="main__news-date">02/02/2020</div>
                <div className="main__news-info">
                  <p className="main__news-info-content">
                    Стимулирование сбыта гармонично. Художественный талант, по
                    определению, многопланово дискредитирует язык образов,
                    расширяя
                  </p>
                  <a href="#" className="main__news-btn">
                    <span className="main__news-btn-content">подробнее</span>
                    <span className="main__news-btn-label"></span>
                  </a>
                </div>
              </div>
              <div className="main__news-card">
                <div className="main__news-date">02/02/2020</div>
                <div className="main__news-info">
                  <p className="main__news-info-content">
                    Стимулирование сбыта гармонично. Художественный талант, по
                    определению, многопланово дискредитирует язык образов,
                    расширяя
                  </p>
                  <a href="#" className="main__news-btn">
                    <span className="main__news-btn-content">подробнее</span>
                    <span className="main__news-btn-label"></span>
                  </a>
                </div>
              </div>
            </div>

            <div className="main__news-nav news-nav">
              <span className="news-nav__range-bar-count">0</span>
              <input
                type="range"
                className="news-nav__range"
                name="range"
                min="0"
                max="3"
                step="1"
                value={range}
                onChange={handleChange}
              />
              <span className="news-nav__range-bar-count">03</span>
            </div>
          </div>
        </div>
        <div className="main__about-us">
          <AboutUs />
        </div>
        <div className="main__popular-projects popular-projects">
          <div className="popular-projects__header">
            <h3 className="popular-projects__header-title">Проекты</h3>
            <a
              href="#"
              className="popular-projects__header-btn header-btn header-btn--top"
            >
              <span className="header-btn__content content content--top">
                БОЛЬШЕ ПРОЕКТОВ
              </span>
            </a>
          </div>
          <ProjectsBlock />
          <a
            href="#"
            className="popular-projects__header-btn header-btn header-btn--bottom"
          >
            <span className="header-btn__content content content--bottom">
              БОЛЬШЕ ПРОЕКТОВ
            </span>
          </a>
        </div>
        <div className="main__collaboration">
          <Collaboration />
        </div>
      </div>
    </section>
  );
};

export default Main;
